"""Single content source for the Beamer deck, editable PPTX and Korean speaker script."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2]
slides=[]
def slide(title,kind,bullets,script,**kw):
    slides.append(dict(title=title,kind=kind,bullets=bullets,script=script,**kw))
slide('Probe-Gated Critic Transfer','cover',[
 'Latent Team Discovery from Individual Reward Responses','Research draft | 2 November 2026'],
 '안녕하세요. 이번 발표에서는 개인 보상 응답으로 잠재 팀을 찾고, 발견한 팀원의 Critic 정보를 선택적으로 활용하는 PGCT를 설명하겠습니다. 같은 공간에 있는 로봇이라도 목표가 다를 수 있다는 문제에서 시작합니다. 현재 발견 구성요소의 로그와 통합 구현 검증은 있지만, 최종 알고리즘의 장기 학습 성능은 아직 확인 중입니다. 오늘은 확인된 내용과 남은 검증을 구분해서 말씀드리겠습니다.')
slide('Outline','bullets',['Introduction','Proposed Method','Simulation Results','Conclusion'],
 '먼저 어떤 상황에서 팀 발견이 필요한지 설명하고, 관련 방법과의 차이를 정리하겠습니다. 이어서 개인 보상 예측부터 probe 비교, Critic 선택, advantage 계산까지 한 흐름으로 설명합니다. 실험 부분에서는 실제 로그에서 확인한 발견 결과와 독립 PPO 기준선을 보여 드리겠습니다. 아직 없는 PGCT 학습 결과는 대기 상태로 표시하겠습니다.')
slide('Introduction: Research Background','background',[
 'Robots share a workspace, but may serve different goals.',
 'Nearby agents can exchange information.',
 'Physical proximity does not imply a common task.'],
 '여러 로봇이 같은 창고에서 움직이는 상황을 생각해 보겠습니다. 어떤 로봇은 왼쪽 목적지로, 다른 로봇은 오른쪽 목적지로 배송해야 합니다. 서로 가까워서 정보를 교환할 수는 있지만, 가까이 있다는 이유만으로 같은 목적의 정보를 공유하면 잘못된 가치 정보를 받을 수 있습니다. 따라서 누구에게서 정보를 받을지 정하기 전에, 상대가 나와 같은 과제를 수행하는지를 알아야 합니다. 오른쪽 그림은 목표 차이를 설명하기 위한 개념도이며 실제 학습 궤적은 아닙니다.')
slide('Introduction: Problem Definition','bullets',[
 'Input: local observations, own actions and own rewards.',
 'Hidden relation: which agents share the task goal?',
 'No team label or scalar reward exchange.',
 'Output: approved peers for selective Critic access.'],
 '문제의 입력은 각 에이전트가 실제로 얻는 관측, 행동, 개인 보상입니다. 우리가 찾는 것은 상대의 정책 자체가 아니라 같은 과제 목표를 갖는 관계입니다. 자기 관측에 자기 목표 정보가 있더라도 상대 팀 라벨은 알려 주지 않습니다. 실제 보상값도 교환하지 않습니다. 대신 공개적으로 표현할 수 있는 사건에 대한 예상 보상을 비교하고, 그 결과를 Critic 접근 대상의 승인으로 사용합니다. 팀 라벨은 결과를 평가할 때만 씁니다.')
slide('Introduction: Related Work','related',[],
 '독립 PPO는 개인 목적이 분명하지만 상대의 지식을 활용하지 못합니다. 경험 공유는 협력 관계가 맞을 때 유용하지만 모든 이웃이 같은 과제라고 볼 수는 없습니다. 선택적 파라미터 공유는 에이전트 사이의 차이를 다루지만, 여기서는 네트워크를 하나로 합치는 대신 개인 Actor와 Critic을 유지합니다. MAMBA는 여러 가치의 최댓값을 advantage에 쓰는 계산의 동기가 됩니다. 다만 우리는 다른 Critic을 내 이력에 외삽하므로 그 성능 보장을 가져오지 않습니다.',
 table=[['Approach','Useful idea','PGCT distinction'],['Independent PPO','Local objective','Select access to peer values'],['Shared experience','Use others\' data','Infer the task relation first'],['Selective sharing','Group similar agents','Keep individual Actors and Critics'],['MAMBA','Maximum of oracle values','Learned peer values are extrapolated']],
 sources=['https://arxiv.org/abs/1707.06347','https://proceedings.neurips.cc/paper/2020/hash/7967cc8e3ab559e68cc944c44b1cf3e8-Abstract.html','https://proceedings.mlr.press/v139/christianos21a.html','https://proceedings.neurips.cc/paper/2020/hash/3c56fe2f24038c4d22b9eb0aca78f590-Abstract.html'])
slide('Introduction: Research Goal and Contributions','bullets',[
 'Goal: discover latent teammates from reward responses.',
 'Compare public event probes; abstain without evidence.',
 'Use approved peer Critics in the Actor advantage.',
 'Keep each Critic focused on its own return.'],
 '연구의 중심 목표는 잠재 팀 발견입니다. 이를 위해 개인 보상 예측기를 공통 사건 probe에 질의하고, 근거가 부족할 때는 판단을 보류합니다. 발견 결과는 승인된 상대 Critic에 접근하는 데 사용합니다. 그 가치 차이를 Actor advantage에 넣되, 개인 Critic이 추정하는 목적은 자기 return으로 유지합니다. 이 구성이 학습을 빠르게 한다는 것은 앞으로 검증할 가설이며, 현재 기여 설명에는 그 효과를 입증한 것처럼 넣지 않았습니다.')
slide('Proposed Method: Overall PGCT Architecture','architecture',[
 'Local learning → reward responses → team discovery → selective Critic use',
 'Individual rewards and own-return targets stay private.'],
 '전체 흐름입니다. 독립 학습으로 모은 자기 경험에서 보상 예측기를 학습합니다. 자기 사건과 상대 사건의 공개 부분으로 공통 probe를 만들고 두 예측기의 응답을 비교합니다. 같은 과제라는 근거가 쌓이면 승인하고, 현재 rollout에서 실제로 만난 승인 상대의 Critic만 사용합니다. 받는 에이전트가 자기 관측열로 그 Critic을 평가해 Max-GAE를 계산하고 Actor를 갱신합니다. 아래의 별도 가지처럼 개인 Critic은 계속 자기 return으로 학습합니다. 이 구조에 중앙 팀 분류기는 없습니다.')
slide('Proposed Method: Individual Reward Prediction','predictor',[
 'Own public transition → MLP → own reward estimate',
 '567 → 128 → 64 → 1; ReLU',
 'Own events: reward ≥ 0.5; 25% of a training batch'],
 '보상 예측기는 관측 전체가 아니라 공개 물리 정보만 봅니다. 전 상태, 행동, 후 상태를 합친 567차원 입력으로 자기 보상을 예측합니다. 중요한 점은 학습 정답이 언제나 자신의 보상이라는 것입니다. 희소한 배송·반납 사건을 놓치지 않도록 별도 buffer에 저장하고 batch의 일부를 사건에서 뽑습니다. 수식은 단순히 공개 전이에서 예상 개인 보상으로 가는 함수를 나타냅니다. 다른 에이전트의 보상을 정답으로 받아 배우는 구조가 아닙니다.',
 equations=[r'\widehat r_i(q)=\mathrm{MLP}_{\psi_i}[P(o_t),\mathrm{onehot}(a_t),P(o_{t+1})]'])
slide('Proposed Method: Reward Probe Construction','probes',[
 'Recent positive events from the two agents',
 'Public before / action / public after',
 'Add left-right mirrors; do not send reward labels.',
 'Task-private request and own-goal channels are removed.'],
 '각 에이전트의 최근 보상 사건을 최대 32개씩 가져오되, 그중 공개 물리 장면과 행동만 교환합니다. 실제 보상 수치는 보내지 않습니다. 같은 사건의 좌우 대칭 장면도 probe에 더합니다. 두 에이전트가 동일한 probe 목록에 답해야 응답의 차이를 비교할 수 있습니다. 자기 요청 선반이나 자기 팀 goal 채널은 probe에서 제거합니다. 아직 보상 사건을 경험하지 못한 에이전트에게 이 절차가 새로운 식별 근거를 만들어 주지는 못합니다.')
slide('Proposed Method: Reward Responses and Team Discovery','distance',[
 'Compare response mass on the same probes.',
 'EMA < 0.5 for at least 3 updated comparison rounds.',
 'Both predictors must be mature; otherwise abstain.'],
 '이 거리는 두 예측기의 응답 차이를 전체 응답 크기로 나눈 값입니다. 중요한 것은 작은 보상값 자체가 아니라 같은 장면에 비슷한 반응을 하는지입니다. 응답이 거의 모두 0이면 판정을 보류합니다. 두 예측기가 각각 최소 20개의 자기 사건을 보고 실제로 학습했으며, 자기 사건을 충분히 예측해야 성숙으로 봅니다. 이후 새 예측기로 비교한 근거가 세 번 이상 쌓이고 평활 거리가 문턱 아래이면 승인합니다. 승인 근거는 접촉이 끊겨도 보존하지만 실제 사용에는 현재 접촉이 다시 필요합니다.',
 equations=[r'D_{ij}=\frac{\sum_{q\in\mathcal Q_{ij}}|\widehat r_i(q)-\widehat r_j(q)|}{\sum_{q\in\mathcal Q_{ij}}(|\widehat r_i(q)|+|\widehat r_j(q)|)}'])
slide('Proposed Method: Selective Peer Critic Access','critics',[
 'Use peers met during the current rollout and reward-approved.',
 'Replay my observation stream through each selected Critic.',
 'Share Critic weights; do not use the donor hidden state.'],
 '선택 조건은 두 가지입니다. 현재 rollout에서 통신 범위 안에서 만났고, 보상 응답으로 승인된 상대여야 합니다. 그 상대의 Critic 가중치를 접근해 내 관측열을 순서대로 넣습니다. 상대가 갖고 있던 hidden state를 가져오는 것은 아닙니다. 따라서 내 상황을 다른 Critic이 어떻게 평가하는지 비교할 수 있습니다. 하지만 다른 Critic이 내 이력에서도 정확하다는 보장은 없습니다. Critic EV 조건은 선택 옵션으로만 구현돼 있고 기본으로 켜져 있지는 않습니다.')
slide('Proposed Method: Max-GAE Advantage Estimation','maxgae',[
 'Positive peer uplift changes the Actor signal.',
 'Shrink large differences; never amplify a small difference.',
 'No donor or no uplift → independent learning.'],
 '승인된 Critic 중 내 가치보다 높은 부분만 양의 상향으로 잡습니다. 그 값을 GAE에 넣어 보조 advantage를 구하고, 자기 advantage와의 차이를 반영합니다. 여기서 shrink는 차이가 너무 클 때만 줄이는 역할을 합니다. 작은 차이를 억지로 큰 신호로 만들지 않습니다. 기본 반영 비중은 절반이지만 실제 반영 비중은 더 작아질 수 있습니다. rollout 처음의 Critic 순환 상태가 충분히 준비되기 전 7 step에는 이 차이를 0으로 둡니다. 이것이 개선 방향까지 보장하는 것은 아닙니다.',
 equations=[r'b_{i,t}=[\max_{j\in\mathcal G_i}V_j(\widetilde h_i^{\,j})-V_i(h_i)]_+,\quad f_{i,t}=V_i(h_i)+w_tb_{i,t}',
 r'A^f_{i,t}=\delta^f_{i,t}+\gamma\lambda(1-d_t)A^f_{i,t+1},\quad\delta^f_{i,t}=r_{i,t}+\gamma(1-d_t)f_{i,t+1}+\gamma z^f_{i,t}-f_{i,t}',
 r'A^{\mathrm{PGCT}}_{i,t}=A^{\mathrm{self}}_{i,t}+\eta s_iw_t(A^f_{i,t}-A^{\mathrm{self}}_{i,t}),\quad\eta=0.5',
 r's_i=\min\left(1,\frac{\mathrm{std}(A_i^{\mathrm{self}})}{\max(\mathrm{std}(w(A_i^f-A_i^{\mathrm{self}})),10^{-8})}\right)'])
slide('Proposed Method: Actor and Critic Updates','updates',[
 'Actor: PPO with normalized PGCT advantage.',
 'Critic: own GAE return; no peer distillation loss.',
 'Own reward is unchanged; peer outputs are detached.',
 'Reward similarity does not guarantee transfer benefit.'],
 '마지막 update에서 Actor는 PGCT advantage를 정규화해 PPO 목적함수에 사용합니다. 반면 Critic의 정답은 자기 보상으로 계산한 기존 GAE return입니다. 남의 Critic 출력에 맞추는 손실은 없습니다. 두 네트워크는 분리돼 있지만 전체 gradient clipping은 공유하므로 Critic 목표가 같다고 수치 update까지 같다고 단정하지는 않습니다. 정리하면 개인 보상과 Critic 목적은 유지하고 Actor에만 선택적인 보조 신호를 넣는 구조입니다. 이 보조 신호가 도움이 되는지는 실험으로 확인해야 합니다.',
 equations=[r'R_{i,t}^{\mathrm{self}}=A_{i,t}^{\mathrm{self}}+V_i^{\mathrm{old}}(h_{i,t})'])
slide('Simulation Results: Experimental Setup','setup',[],
 '주 실험은 11 곱하기 10 창고이며 에이전트 6개가 두 팀에 3개씩 속합니다. 서로 반대 모서리에 goal이 있고 팀별 요청 선반은 3개입니다. 개인 보상만 사용하며 센서는 반경 5, 통신은 반경 3입니다. 장기 평가는 고정된 reset seed 20개에서 500 step씩 deterministic하게 수행합니다. 진행 중인 분기는 공통 1M checkpoint에서 추가 0.5M을 학습하는 비교이므로, 처음부터 독립적으로 학습한 seed 반복과 구분합니다. 이 자료 제작을 위해 새 실험을 실행하지 않았습니다.',
 table=[['Setting','Value'],['Warehouse / agents','11 × 10 / 6 (3 + 3)'],['Goals / requests per team','Opposite corners / 3'],['Sensor / contact radius','5 / 3 (Chebyshev)'],['Reward / observation','Individual / coordinates masked'],['Rollout / gamma / lambda','1024 / 0.99 / 0.95'],['Evaluation','20 fixed resets × 500 steps'],['Branch plan','Common 1.024M start + 0.5M; seeds 1, 3, 5']])
slide('Simulation Results: Team Discovery','discovery_chart',[
 'Observed allocation share: 93.72% same team.',
 '5,252 same-team / 352 cross-team arc-updates.',
 'First cross-team allocation: 4.280M steps.',
 'Component diagnostic only; one seed.'],
 '여기는 실제 보상 발견 로그에서 추출한 결과입니다. 약 5M step, seed 1에서 기록된 directed allocation은 같은 팀 5,252개, 다른 팀 352개였고 같은 팀 비중은 93.72퍼센트입니다. 이것은 반복 사용된 쌍까지 포함한 allocation 비중이지 모든 쌍의 분류 정확도는 아닙니다. 다른 팀 전이는 약 4.28M부터 생겼습니다. 그래프 평균 거리가 문턱 위여도 일부 쌍은 그 아래일 수 있습니다. 이 로그는 update 종료 위치로 접촉을 정한 발견 구성요소의 기록입니다. rollout 접촉을 쓰는 최종 PGCT의 donor 정밀도나 학습 성능으로 해석하지 않습니다.',
 footer='Corner goals · individual rewards · seed 1 · 5.000M steps; discovery-component log, update-end contacts')
slide('Simulation Results: Learning Performance','learning_chart',[
 'Independent PPO baseline: observed curve only.',
 'Final PGCT comparison: pending.',
 '72 tests passed; 64-step smoke verifies wiring only.'],
 '왼쪽은 완료된 독립 PPO seed 1의 실제 평가 곡선입니다. 아직 최종 PGCT 곡선은 없기 때문에 빈 자리에 가짜 곡선을 넣지 않았습니다. 오른쪽 표는 PGCT와 정답 팀, 성숙 oracle, donor 수를 맞춘 비교의 결과 대기 영역입니다. 72개 구현 테스트와 짧은 실제 trainer smoke에서는 차단 시 독립 PPO와 같아지고, 테스트용 정답 승인을 넣으면 정답 팀 Max-GAE와 같아지는 것을 확인했습니다. 하지만 64 step 검사는 장기 학습 효과나 통계적 우수성을 보여 주는 결과가 아닙니다.',
 footer='Baseline: corner goals · individual rewards · seed 1; 20 deterministic episodes × 500 steps / evaluation')
slide('Conclusion','bullets',[
 'Latent team discovery is the central objective.',
 'Individual reward responses guide selective Critic access.',
 'Masked, shrunk Max-GAE shapes the Actor advantage.',
 'Open: long-run benefit, event-free agents, late false approvals.'],
 'PGCT의 중심은 같은 공간의 에이전트를 무조건 묶는 것이 아니라 개인 보상 응답으로 잠재 팀을 발견하는 것입니다. 공개 사건 probe에 대한 응답으로 상대를 승인하고, 실제로 만난 승인 상대의 Critic만 Actor advantage에 사용합니다. 개인 Critic은 자기 return을 유지합니다. 발견 구성요소의 관측과 통합 구현 검증은 확보했지만, 장기 학습 이득은 아직 열린 질문입니다. 보상 사건이 없는 에이전트와 후반의 잘못된 승인도 해결해야 합니다. 이 한계를 포함해 후속 실험 결과를 채워 넣겠습니다. 감사합니다.')
assert len(slides)==17
(ROOT/'presentation/slides.json').write_text(json.dumps(slides,ensure_ascii=False,indent=2),encoding='utf-8')
script=['# PGCT 한국어 발표 대본','', '17장, 약 12–15분을 위한 제안 대본. 실제 녹음의 전사나 발표자 말투를 복원한 문서가 아니다.','']
for i,s in enumerate(slides,1): script.extend([f'## {i}. {s["title"]}', '',s['script'],''])
(ROOT/'presentation/pgct_script_ko.md').write_text('\n'.join(script),encoding='utf-8')
