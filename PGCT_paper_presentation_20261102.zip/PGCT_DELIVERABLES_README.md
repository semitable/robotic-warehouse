# PGCT 영어·한국어 논문과 발표자료 — 2026-11-02

## 결과물

| 파일 | 내용 |
|---|---|
| `paper/english/main.tex`, `main.pdf` | 영어 전체 초안, 7쪽 |
| `paper/korean/main.tex`, `main.pdf` | 동일한 기술 내용의 한국어 전체 초안, 7쪽 |
| `paper/method_equations.tex` | 두 논문이 동일하게 호출하는 11개 수식 블록 |
| `paper/references.bib` | 공통 BibTeX 참고문헌 |
| `paper/figures/` | 새 구조도 3개의 TikZ 원본, 실제 로그 그래프와 CSV |
| `presentation/pgct_beamer.tex`, `pgct_beamer.pdf` | 16:9 영어 Beamer, 17장 |
| `presentation/pgct_presentation.pptx` | 동일한 내용·순서의 편집 가능한 PowerPoint, 17장 |
| `presentation/pgct_script_ko.md` | 슬라이드별 자연스러운 한국어 제안 대본 |
| `presentation/slides.json` | Beamer·PPTX·대본의 공통 내용 원본 |
| `presentation/reference_analysis_ko.md` | 참고 PDF 전체 구성·디자인 분석과 녹음 접근 한계 |
| `paper/evidence_manifest.json` | 실제 로그 경로, 수치, 코드 해시, 읽기 전용 실행 상태 스냅샷 |

저자·소속 정보는 제공되지 않아 논문은 익명으로 작성했다. 참고 발표자의 이름·소속·지원 문구는 복사하지 않았다. 이 대화에서 확인할 수 없는 이전 영어 논문 세부 지시를 복원했다고 주장하지 않으며, 현재 사용자 요청·최종 코드·공용 연구 기록을 기준으로 구성했다.

## 주장과 결과의 경계

모든 자료에서 PGCT는 개인 보상 MLP → 공개 사건 probe → 정규화 응답 거리와 성숙·지속 승인 → rollout 접촉 교집합 → 승인된 Critic에 자기 관측열 질의 → mask·shrink Max-GAE Actor advantage → 개인 PPO와 자기 return Critic update로 설명한다. Critic EV 문턱은 선택 옵션이며 기본 비활성, 유한 상향 cap도 기본으로 정하지 않았다. 통합 알고리즘의 장기 학습 이득은 아직 입증하지 않았다.

약 5M step·seed 1의 보상 발견 로그는 **발견 구성요소 진단**으로만 사용한다. 같은 팀 5,252 / 다른 팀 352 directed allocation 누적, 비중 93.72%, 첫 다른 팀 allocation 4,280,320 step은 원본 `transfer.jsonl`에서 다시 계산했다. 이는 쌍 분류 정확도가 아니며, 현재 rollout 접촉 기반 PGCT donor의 정밀도도 아니다. 해당 로그의 접촉 기준은 update 종료 위치였다는 차이를 논문·슬라이드·대본에 명시했다.

학습 그래프는 완료된 독립 PPO seed 1 기준선만 표시한다. 최종 PGCT·oracle·donor 수 일치 비교는 `Pending`이다. 진행 중인 공통 checkpoint 분기의 부분 곡선을 최종 결과로 넣지 않았다. 72개 테스트와 64-step smoke는 이전 구현 검증 기록이며, 이 문서 제작 중 테스트나 환경 rollout을 다시 실행한 것이 아니다.

## 참고자료와 녹음

`이기윤_ICCAS.pdf`는 16장 전체 텍스트와 렌더링을 확인했다. 흰 배경·파란 제목·배경/한계/기여/전체 구조/구성요소/실험/결론의 설명 순서만 참고했다. Multi-UAV 알고리즘·식·그림·성능 수치는 가져오지 않았다.

`음성 261023_135711.m4a`는 파일 접근과 M4A 컨테이너 메타데이터로 812.9793초(약 13분 33초)를 확인했다. 음성 전사 도구·모델이 없어 전사·청취 기반 분석은 못 했다. 실제 발화·강조·수식 설명 시간을 추측하지 않았다. 한국어 대본은 새 제안 대본이다.

## 편집성

PPTX는 사용자 요청에 맞춰 `python-pptx`로 만들었다. 본문, 표 3개, 그래프 2개와 도식은 네이티브 개체다. 그래프에는 편집 가능한 내장 데이터가 있다. **8·10·12·13번 슬라이드 수식만 PNG 조각**이며, 전체 페이지를 이미지로 넣은 PPTX가 아니다. 수식의 LaTeX 원본은 `slides.json`에 있다. 모든 슬라이드에 한국어 발표 대본을 speaker notes로도 넣었다.

PPTX는 Artifact Tool로 전 장을 렌더링했고 구조·배치 검사에서 finding 0을 확인했다. Microsoft PowerPoint 앱 자체에서 열어 검사한 것은 아니다. 다른 PC에서 Arial·수식 이미지·표의 배치를 한 번 확인하면 좋다.

## LaTeX 빌드

실제 빌드는 Tectonic 0.17.0(XeTeX 기반)으로 성공했다. Windows의 Times New Roman·Arial·Malgun Gothic을 사용한다. 한국어는 `kotex`와 XeLaTeX를 사용한다. 다른 OS에서는 설치된 CJK 글꼴로 `\setmainhangulfont`를 조정할 수 있다.

일반 XeLaTeX 환경에서는 각 `main.tex`가 있는 폴더에서 다음 순서로 실행한다.

```text
xelatex main.tex
bibtex main
xelatex main.tex
xelatex main.tex
```

Beamer는 `presentation/`에서 `xelatex pgct_beamer.tex`를 두 번 실행한다. 세 문서는 그림·공통 수식·문헌 파일을 함께 보관해야 한다. 파일 하나만 복사해 빌드하지 않는다. 최신 TeX 배포판의 XeLaTeX 사용을 권하며, LuaLaTeX 빌드는 이 환경에서 별도로 시험하지 않았다.

논문은 **2단 검토용 작업 초안**이다. 공식 목표 연도 IJCAI 스타일·저자 정보·분량 규정까지 검증한 투고본은 아니다. 실제 결과를 채운 뒤 공식 양식으로 옮겨야 한다. 현재 7쪽에는 참고문헌과 부록도 포함된다.

## 재생성과 확인

제작 스크립트는 `output/pgct_authoring_20261102/`에 있다. ZIP에도 같은 상대 경로로 재생성에 필요한 스크립트와 `quality_report.json`을 넣었다. TeX 실행 파일·캐시·사용자 첨부 원본은 ZIP에 넣지 않았다. RWARE 환경은 matplotlib 그래프·수식 렌더링에만 사용했고 trainer를 import하거나 실행하지 않았다. 번들 Python은 PDF·PPTX 생성에 사용했다.

`quality_report.json`은 한영 수식 11개·인용 7개·figure/table label 일치, 17장과 대본의 순서, 연구 코드 해시 불변, PDF에 Overfull/누락 glyph/컴파일 오류 없음 등을 기록한다. 한글의 이탤릭 대체와 외부 글꼴 경로 경고, 일부 underfull 경고는 남지만 시각 검사에서 글자·그림 잘림은 없었다.

원본 실험·체크포인트·로그를 덮어쓰지 않았고, 연구 코드·학습 설정·실행 중인 학습을 바꾸거나 새로 실행하지 않았다. 문서 제작용 TeX 실행 파일과 패키지 캐시만 프로젝트의 새 제작 폴더에 받았다. 커밋은 하지 않았다.
